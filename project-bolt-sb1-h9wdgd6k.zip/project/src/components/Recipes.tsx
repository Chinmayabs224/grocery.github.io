import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import RecipeCard from './RecipeCard';
import { recipes, recipeCategories, recipeTags } from '../data/recipes';

const Recipes = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeTags, setActiveTags] = useState<string[]>([]);

  const toggleTag = (tag: string) => {
    if (activeTags.includes(tag)) {
      setActiveTags(activeTags.filter(t => t !== tag));
    } else {
      setActiveTags([...activeTags, tag]);
    }
  };

  const filteredRecipes = recipes.filter(recipe => {
    // Filter by category
    if (activeCategory !== 'All' && recipe.category !== activeCategory) {
      return false;
    }
    
    // Filter by tags
    if (activeTags.length > 0) {
      return activeTags.every(tag => recipe.tags.includes(tag));
    }
    
    return true;
  });

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section className="py-16 bg-white" ref={ref}>
      <div className="container-custom">
        <div className="text-center mb-8">
          <motion.h2 
            className="section-title"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            Featured Recipes
          </motion.h2>
          <motion.p 
            className="section-subtitle"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Discover delicious recipes made with our fresh ingredients
          </motion.p>
        </div>
        
        {/* Category Filter */}
        <motion.div 
          className="flex flex-wrap justify-center gap-2 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          {recipeCategories.map((category) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === category
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </motion.div>
        
        {/* Tags Filter */}
        <motion.div 
          className="flex flex-wrap justify-center gap-2 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          {recipeTags.map((tag) => (
            <button
              key={tag}
              className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                activeTags.includes(tag)
                  ? 'bg-secondary-100 text-secondary-800 border-secondary-300'
                  : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
              }`}
              onClick={() => toggleTag(tag)}
            >
              {tag}
            </button>
          ))}
          
          {activeTags.length > 0 && (
            <button
              className="px-3 py-1 rounded-full text-xs font-medium text-gray-600 underline"
              onClick={() => setActiveTags([])}
            >
              Clear filters
            </button>
          )}
        </motion.div>

        {/* Recipe Grid */}
        {filteredRecipes.length > 0 ? (
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
          >
            {filteredRecipes.map((recipe) => (
              <motion.div key={recipe.id} variants={itemVariants}>
                <RecipeCard recipe={recipe} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div 
            className="text-center py-8"
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
          >
            <p className="text-gray-500">No recipes match your current filters.</p>
            <button
              className="mt-4 text-primary-600 underline"
              onClick={() => {
                setActiveCategory('All');
                setActiveTags([]);
              }}
            >
              Clear all filters
            </button>
          </motion.div>
        )}
        
        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <button className="btn btn-primary">
            View All Recipes
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default Recipes;