import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 w-full h-full z-0">
        <div className="absolute inset-0 bg-black bg-opacity-40 z-10"></div>
        <video 
          className="absolute w-full h-full object-cover"
          autoPlay 
          muted 
          loop 
          playsInline
        >
          <source 
            src="https://player.vimeo.com/progressive_redirect/playback/735428832/rendition/720p/file.mp4?loc=external&oauth2_token_id=1747418641&signature=e5da7f95a75bd961d142c3d9fa6e5ba9b0f23eb883ed5da444e62eb8c9975903" 
            type="video/mp4" 
          />
          Your browser does not support the video tag.
        </video>
      </div>

      {/* Floating Images Grid */}
      <div className="absolute inset-0 z-5 pointer-events-none">
        <motion.div 
          className="absolute top-[15%] left-[10%] w-32 h-32"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <img 
            src="https://images.pexels.com/photos/2899682/pexels-photo-2899682.jpeg" 
            alt="Fresh vegetables"
            className="w-full h-full object-cover rounded-2xl shadow-lg"
          />
        </motion.div>
        
        <motion.div 
          className="absolute top-[25%] right-[15%] w-40 h-40"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <img 
            src="https://images.pexels.com/photos/1508666/pexels-photo-1508666.jpeg" 
            alt="Colorful fruits"
            className="w-full h-full object-cover rounded-2xl shadow-lg"
          />
        </motion.div>
        
        <motion.div 
          className="absolute bottom-[20%] left-[20%] w-36 h-36"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
        >
          <img 
            src="https://images.pexels.com/photos/3026808/pexels-photo-3026808.jpeg" 
            alt="Fresh bread"
            className="w-full h-full object-cover rounded-2xl shadow-lg"
          />
        </motion.div>
        
        <motion.div 
          className="absolute bottom-[30%] right-[20%] w-28 h-28"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
        >
          <img 
            src="https://images.pexels.com/photos/4871119/pexels-photo-4871119.jpeg" 
            alt="Organic herbs"
            className="w-full h-full object-cover rounded-2xl shadow-lg"
          />
        </motion.div>
      </div>

      {/* Content */}
      <div className="container-custom relative z-20 text-center text-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
            Fresh Ingredients, <br />
            <span className="text-secondary-300">Delivered Daily</span>
          </h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8 text-gray-100">
            Discover the finest organic produce, artisanal goods, and everyday essentials
            delivered straight to your door.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn btn-primary px-8 py-3 rounded-full"
            >
              Shop Now
              <ArrowRight className="ml-2" size={18} />
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn border-2 border-white text-white hover:bg-white hover:text-gray-800 px-8 py-3 rounded-full"
            >
              View Weekly Deals
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ duration: 1.5, repeat: Infinity }}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 5v14M5 12l7 7 7-7"/>
        </svg>
      </motion.div>
    </div>
  );
};

export default Hero;