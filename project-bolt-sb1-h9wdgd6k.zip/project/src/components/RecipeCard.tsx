import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Users } from 'lucide-react';
import { Recipe } from '../data/recipes';

interface RecipeCardProps {
  recipe: Recipe;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe }) => {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="product-card bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300"
    >
      <div className="relative">
        <img 
          src={recipe.image} 
          alt={recipe.title}
          className="w-full h-48 object-cover"
        />
        
        <div className="absolute top-2 left-2 bg-white bg-opacity-90 text-primary-700 text-xs px-2 py-1 rounded-full">
          {recipe.category}
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent h-16">
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-medium text-gray-800 mb-2 line-clamp-2">{recipe.title}</h3>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{recipe.shortDescription}</p>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {recipe.tags.slice(0, 2).map((tag) => (
            <span 
              key={tag}
              className="text-xs text-primary-700 bg-primary-50 px-2 py-0.5 rounded-full"
            >
              {tag}
            </span>
          ))}
          {recipe.tags.length > 2 && (
            <span className="text-xs text-gray-500 px-1">
              +{recipe.tags.length - 2} more
            </span>
          )}
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-600">
          <div className="flex items-center">
            <Clock size={14} className="mr-1" />
            <span>{recipe.prepTime + recipe.cookTime} mins</span>
          </div>
          
          <div className="flex items-center">
            <Users size={14} className="mr-1" />
            <span>Serves {recipe.servings}</span>
          </div>
          
          <div className="px-2 py-0.5 bg-gray-100 rounded text-xs font-medium text-gray-700">
            {recipe.difficulty}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default RecipeCard;