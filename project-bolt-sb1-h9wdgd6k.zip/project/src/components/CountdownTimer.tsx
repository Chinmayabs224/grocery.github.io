import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  endTime: Date;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ endTime }) => {
  const calculateTimeLeft = () => {
    const difference = +endTime - +new Date();
    let timeLeft = { days: 0, hours: 0, minutes: 0, seconds: 0 };

    if (difference > 0) {
      timeLeft = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }

    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearTimeout(timer);
  });

  const timerComponents = [
    { label: 'Days', value: timeLeft.days },
    { label: 'Hours', value: timeLeft.hours },
    { label: 'Mins', value: timeLeft.minutes },
    { label: 'Secs', value: timeLeft.seconds },
  ];

  return (
    <div className="flex space-x-2 sm:space-x-3">
      {timerComponents.map((component) => (
        <div
          key={component.label}
          className="flex flex-col items-center"
        >
          <div className="bg-white text-secondary-700 rounded-md px-2 py-1 min-w-[40px] text-center font-semibold">
            {component.value.toString().padStart(2, '0')}
          </div>
          <span className="text-xs text-gray-500 mt-1">{component.label}</span>
        </div>
      ))}
    </div>
  );
};

export default CountdownTimer;