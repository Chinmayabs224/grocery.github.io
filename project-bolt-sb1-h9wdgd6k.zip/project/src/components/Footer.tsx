import React from 'react';
import { motion } from 'framer-motion';
import { 
  Facebook, 
  Instagram, 
  Twitter, 
  Youtube, 
  MapPin, 
  Phone, 
  Mail,
  Clock,
  ArrowRight,
  Leaf
} from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  const storeHours = [
    { day: 'Monday - Friday', hours: '8:00 AM - 9:00 PM' },
    { day: 'Saturday', hours: '8:00 AM - 8:00 PM' },
    { day: 'Sunday', hours: '9:00 AM - 6:00 PM' }
  ];
  
  const socialLinks = [
    { icon: <Facebook size={20} />, url: '#', name: 'Facebook' },
    { icon: <Instagram size={20} />, url: '#', name: 'Instagram' },
    { icon: <Twitter size={20} />, url: '#', name: 'Twitter' },
    { icon: <Youtube size={20} />, url: '#', name: 'YouTube' }
  ];
  
  const quickLinks = [
    { name: 'About Us', url: '#' },
    { name: 'Locations', url: '#' },
    { name: 'Careers', url: '#' },
    { name: 'Weekly Flyer', url: '#' },
    { name: 'Gift Cards', url: '#' },
    { name: 'Loyalty Program', url: '#' }
  ];

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container-custom pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <Leaf className="text-primary-500 mr-2" size={24} />
              <span className="text-xl font-serif font-bold text-white">
                Fresh<span className="text-primary-500">Nest</span>
              </span>
            </div>
            
            <p className="mb-4 text-gray-400">
              Your neighborhood grocer committed to providing the freshest, highest-quality foods 
              while supporting local farmers and sustainable practices.
            </p>
            
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="mt-1 mr-2 flex-shrink-0 text-primary-500" size={18} />
                <span>123 Fresh Avenue, Harvest Hills, CA 90210</span>
              </li>
              <li className="flex items-center">
                <Phone className="mr-2 flex-shrink-0 text-primary-500" size={18} />
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <Mail className="mr-2 flex-shrink-0 text-primary-500" size={18} />
                <span>hello@freshnest.com</span>
              </li>
            </ul>
          </div>
          
          {/* Store Hours */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Store Hours</h3>
            <ul className="space-y-3">
              {storeHours.map((item, index) => (
                <li key={index} className="flex items-start">
                  <Clock className="mt-1 mr-2 flex-shrink-0 text-primary-500" size={18} />
                  <div>
                    <span className="block text-white">{item.day}</span>
                    <span className="text-gray-400">{item.hours}</span>
                  </div>
                </li>
              ))}
            </ul>
            
            <div className="mt-6 p-3 bg-gray-800 rounded-lg">
              <p className="text-sm text-primary-300 font-medium">
                Holiday Hours May Vary
              </p>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.url} 
                    className="inline-flex items-center text-gray-400 hover:text-primary-400 transition-colors"
                  >
                    <ArrowRight className="mr-2" size={14} />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
            
            <h3 className="text-lg font-semibold text-white mt-6 mb-4">Departments</h3>
            <div className="flex flex-wrap gap-2">
              {['Produce', 'Bakery', 'Meat', 'Dairy', 'Deli', 'Seafood'].map((dept) => (
                <a 
                  key={dept}
                  href="#" 
                  className="text-sm px-3 py-1 bg-gray-800 rounded-full text-gray-300 hover:bg-primary-900 hover:text-primary-300 transition-colors"
                >
                  {dept}
                </a>
              ))}
            </div>
          </div>
          
          {/* Social & App */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Connect With Us</h3>
            <div className="flex space-x-3 mb-6">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.url}
                  className="bg-gray-800 p-2 rounded-full text-gray-300 hover:bg-primary-600 hover:text-white transition-colors"
                  aria-label={social.name}
                  whileHover={{ y: -3 }}
                >
                  {social.icon}
                </motion.a>
              ))}
            </div>
            
            <h3 className="text-lg font-semibold text-white mb-4">Download Our App</h3>
            <div className="space-y-3">
              <a href="#" className="block">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg" 
                  alt="Download on the App Store" 
                  className="h-10"
                />
              </a>
              <a href="#" className="block">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" 
                  alt="Get it on Google Play" 
                  className="h-10"
                />
              </a>
            </div>
          </div>
        </div>
        
        <hr className="border-gray-800 mb-8" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0 text-sm text-gray-500">
            &copy; {currentYear} FreshNest Grocery. All rights reserved.
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500">
            <a href="#" className="hover:text-primary-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary-400 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-primary-400 transition-colors">Accessibility</a>
            <a href="#" className="hover:text-primary-400 transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;