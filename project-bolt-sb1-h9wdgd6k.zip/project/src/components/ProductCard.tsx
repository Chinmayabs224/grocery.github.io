import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Plus, Leaf } from 'lucide-react';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="product-card bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300"
    >
      <div className="relative">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        
        {/* Badge for Organic */}
        {product.isOrganic && (
          <div className="absolute top-2 left-2 bg-primary-500 text-white text-xs px-2 py-1 rounded-full flex items-center">
            <Leaf size={12} className="mr-1" />
            <span>Organic</span>
          </div>
        )}
        
        {/* Badge for Sale */}
        {product.isOnSale && (
          <div className="absolute top-2 right-2 bg-secondary-500 text-white text-xs px-2 py-1 rounded-full">
            {product.salePercentage}% OFF
          </div>
        )}
        
        {/* Quick Add Button */}
        <motion.button 
          className="absolute bottom-2 right-2 bg-white rounded-full p-2 shadow-md text-primary-600 hover:bg-primary-600 hover:text-white transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Plus size={18} />
        </motion.button>
      </div>
      
      <div className="p-4">
        <div className="text-xs text-gray-500 mb-1">{product.category}</div>
        <h3 className="font-medium text-gray-800 mb-2">{product.name}</h3>
        
        <div className="flex items-center justify-between">
          <div>
            {product.isOnSale ? (
              <div className="flex items-center">
                <span className="text-primary-600 font-semibold">${product.price.toFixed(2)}</span>
                <span className="text-gray-400 text-sm line-through ml-2">${product.originalPrice?.toFixed(2)}</span>
              </div>
            ) : (
              <span className="text-primary-600 font-semibold">${product.price.toFixed(2)}</span>
            )}
            <span className="text-gray-500 text-sm ml-1">/ {product.unit}</span>
          </div>
          
          <motion.button 
            className="text-gray-600 hover:text-primary-600 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <ShoppingCart size={18} />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;