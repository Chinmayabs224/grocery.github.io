import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  ShoppingCart, 
  User, 
  Search, 
  Menu, 
  X, 
  ChevronDown,
  Leaf
} from 'lucide-react';

const navItems = [
  { 
    name: 'Shop', 
    hasSubmenu: true,
    submenu: ['Fruits & Vegetables', 'Dairy & Eggs', 'Meat & Seafood', 'Bakery', 'Pantry', 'Beverages']
  },
  { name: 'Weekly Deals', hasSubmenu: false },
  { name: 'Recipes', hasSubmenu: false },
  { 
    name: 'About Us', 
    hasSubmenu: true,
    submenu: ['Our Story', 'Sustainability', 'Careers', 'Press']
  },
  { name: 'Locations', hasSubmenu: false },
];

const Header = () => {
  const [isSticky, setIsSticky] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const toggleSubmenu = (itemName: string) => {
    if (activeSubmenu === itemName) {
      setActiveSubmenu(null);
    } else {
      setActiveSubmenu(itemName);
    }
  };

  return (
    <header 
      className={`py-4 w-full z-50 transition-all duration-300 ${
        isSticky ? 'fixed top-0 bg-white shadow-md' : 'absolute'
      }`}
    >
      <div className="container-custom flex items-center justify-between">
        {/* Logo */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="flex items-center"
        >
          <Leaf className="text-primary-600 mr-2" size={28} />
          <span className="text-2xl font-serif font-bold text-gray-800">
            Fresh<span className="text-primary-600">Nest</span>
          </span>
        </motion.div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-6">
          {navItems.map((item) => (
            <div key={item.name} className="relative group">
              <button 
                className="flex items-center text-gray-700 hover:text-primary-600 transition-colors"
                onClick={() => item.hasSubmenu && toggleSubmenu(item.name)}
              >
                {item.name}
                {item.hasSubmenu && (
                  <ChevronDown className="ml-1" size={16} />
                )}
              </button>
              
              {item.hasSubmenu && (
                <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 z-20 hidden group-hover:block">
                  {item.submenu?.map((subItem) => (
                    <a 
                      key={subItem}
                      href="#" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary-50 hover:text-primary-600"
                    >
                      {subItem}
                    </a>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden lg:flex items-center space-x-4">
          <button className="p-2 text-gray-700 hover:text-primary-600 transition-colors">
            <Search size={20} />
          </button>
          <button className="p-2 text-gray-700 hover:text-primary-600 transition-colors">
            <User size={20} />
          </button>
          <button className="p-2 text-gray-700 hover:text-primary-600 transition-colors relative">
            <ShoppingCart size={20} />
            <span className="absolute -top-1 -right-1 bg-secondary-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              3
            </span>
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="lg:hidden p-2 text-gray-700 focus:outline-none" 
          onClick={toggleMobileMenu}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className="lg:hidden bg-white shadow-md pt-4 pb-6 px-4"
        >
          <nav className="space-y-4">
            {navItems.map((item) => (
              <div key={item.name} className="py-2">
                <button 
                  className="flex items-center justify-between w-full text-gray-700"
                  onClick={() => item.hasSubmenu && toggleSubmenu(item.name)}
                >
                  <span>{item.name}</span>
                  {item.hasSubmenu && (
                    <ChevronDown 
                      className={`transition-transform ${
                        activeSubmenu === item.name ? 'rotate-180' : ''
                      }`} 
                      size={16} 
                    />
                  )}
                </button>
                
                {item.hasSubmenu && activeSubmenu === item.name && (
                  <div className="mt-2 pl-4 space-y-2 border-l-2 border-primary-200">
                    {item.submenu?.map((subItem) => (
                      <a 
                        key={subItem}
                        href="#" 
                        className="block py-1 text-sm text-gray-600 hover:text-primary-600"
                      >
                        {subItem}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>
          
          <div className="mt-6 flex items-center justify-between">
            <button className="p-2 text-gray-700 hover:text-primary-600 transition-colors">
              <Search size={20} />
            </button>
            <button className="p-2 text-gray-700 hover:text-primary-600 transition-colors">
              <User size={20} />
            </button>
            <button className="p-2 text-gray-700 hover:text-primary-600 transition-colors relative">
              <ShoppingCart size={20} />
              <span className="absolute -top-1 -right-1 bg-secondary-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                3
              </span>
            </button>
          </div>
        </motion.div>
      )}
    </header>
  );
};

export default Header;