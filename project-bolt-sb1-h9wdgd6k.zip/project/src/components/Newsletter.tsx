import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Send, Check } from 'lucide-react';

const Newsletter = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });
  
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      
      // Reset after 5 seconds
      setTimeout(() => {
        setSubscribed(false);
      }, 5000);
    }
  };

  return (
    <section 
      className="py-20 bg-primary-900 text-white relative overflow-hidden" 
      ref={ref}
    >
      {/* Background pattern */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-primary-800 opacity-30 pattern-dots"></div>
      </div>
      
      <div className="container-custom relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 font-serif">
              Get Fresh Updates
            </h2>
            <p className="text-primary-100 mb-8">
              Sign up for our newsletter to receive weekly specials, seasonal recipes, and exclusive offers.
            </p>
          </motion.div>
          
          <motion.form 
            className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            onSubmit={handleSubmit}
          >
            <div className="flex-grow relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="w-full px-4 py-3 rounded-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-secondary-500"
                required
                disabled={subscribed}
              />
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 flex items-center justify-center ${
                subscribed 
                  ? 'bg-green-600 hover:bg-green-700' 
                  : 'bg-secondary-500 hover:bg-secondary-600'
              }`}
              type="submit"
              disabled={subscribed}
            >
              {subscribed ? (
                <>
                  <Check size={18} className="mr-2" />
                  <span>Subscribed!</span>
                </>
              ) : (
                <>
                  <span>Subscribe</span>
                  <Send size={18} className="ml-2" />
                </>
              )}
            </motion.button>
          </motion.form>
          
          <motion.p 
            className="text-sm text-primary-200 mt-4"
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            We respect your privacy and will never share your information.
          </motion.p>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;