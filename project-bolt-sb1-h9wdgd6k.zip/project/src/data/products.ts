export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  unit: string;
  image: string;
  isOrganic: boolean;
  isOnSale: boolean;
  salePercentage?: number;
  originalPrice?: number;
}

export const featuredProducts: Product[] = [
  {
    id: 1,
    name: 'Organic Avocados',
    category: 'Fruits',
    price: 3.99,
    unit: 'each',
    image: 'https://images.pexels.com/photos/5945755/pexels-photo-5945755.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: false
  },
  {
    id: 2,
    name: 'Fresh Strawberries',
    category: 'Fruits',
    price: 4.99,
    unit: 'basket',
    image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: true,
    salePercentage: 15,
    originalPrice: 5.99
  },
  {
    id: 3,
    name: 'Organic Kale Bunch',
    category: 'Vegetables',
    price: 2.49,
    unit: 'bunch',
    image: 'https://images.pexels.com/photos/539431/pexels-photo-539431.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: false
  },
  {
    id: 4,
    name: 'Artisanal Sourdough Bread',
    category: 'Bakery',
    price: 6.99,
    unit: 'loaf',
    image: 'https://images.pexels.com/photos/1387070/pexels-photo-1387070.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: false,
    isOnSale: false
  },
  {
    id: 5,
    name: 'Free-Range Eggs',
    category: 'Dairy & Eggs',
    price: 5.49,
    unit: 'dozen',
    image: 'https://images.pexels.com/photos/5806599/pexels-photo-5806599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: false
  },
  {
    id: 6,
    name: 'Wild-Caught Salmon',
    category: 'Seafood',
    price: 12.99,
    unit: 'lb',
    image: 'https://images.pexels.com/photos/3296432/pexels-photo-3296432.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: false,
    isOnSale: true,
    salePercentage: 20,
    originalPrice: 16.99
  },
  {
    id: 7,
    name: 'Organic Honey',
    category: 'Pantry',
    price: 8.99,
    unit: 'jar',
    image: 'https://images.pexels.com/photos/1638280/pexels-photo-1638280.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: false
  },
  {
    id: 8,
    name: 'Premium Coffee Beans',
    category: 'Beverages',
    price: 14.99,
    unit: 'bag',
    image: 'https://images.pexels.com/photos/7400258/pexels-photo-7400258.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: false
  }
];

export const weeklyDeals: Product[] = [
  {
    id: 101,
    name: 'Organic Blueberries',
    category: 'Fruits',
    price: 3.99,
    unit: 'pint',
    image: 'https://images.pexels.com/photos/1395958/pexels-photo-1395958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: true,
    salePercentage: 30,
    originalPrice: 5.99
  },
  {
    id: 102,
    name: 'Grass-Fed Ground Beef',
    category: 'Meat',
    price: 7.99,
    unit: 'lb',
    image: 'https://images.pexels.com/photos/618775/pexels-photo-618775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: true,
    salePercentage: 25,
    originalPrice: 10.99
  },
  {
    id: 103,
    name: 'Organic Almond Milk',
    category: 'Dairy Alternatives',
    price: 2.99,
    unit: 'carton',
    image: 'https://images.pexels.com/photos/5947019/pexels-photo-5947019.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: true,
    isOnSale: true,
    salePercentage: 20,
    originalPrice: 3.79
  },
  {
    id: 104,
    name: 'Fresh Baked Croissants',
    category: 'Bakery',
    price: 1.49,
    unit: 'each',
    image: 'https://images.pexels.com/photos/3892469/pexels-photo-3892469.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    isOrganic: false,
    isOnSale: true,
    salePercentage: 35,
    originalPrice: 2.29
  }
];