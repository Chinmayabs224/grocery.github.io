export interface Recipe {
  id: number;
  title: string;
  category: string;
  tags: string[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
  prepTime: number;
  cookTime: number;
  servings: number;
  image: string;
  shortDescription: string;
}

export const recipes: Recipe[] = [
  {
    id: 1,
    title: 'Summer Berry Salad with Honey Lime Dressing',
    category: 'Salads',
    tags: ['Vegetarian', 'Gluten-Free', 'Quick & Easy'],
    difficulty: 'Easy',
    prepTime: 15,
    cookTime: 0,
    servings: 4,
    image: 'https://images.pexels.com/photos/1099680/pexels-photo-1099680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    shortDescription: 'A refreshing salad featuring seasonal berries with a zesty honey lime dressing.'
  },
  {
    id: 2,
    title: 'Roasted Vegetable & Quinoa Bowl',
    category: 'Bowls',
    tags: ['Vegetarian', 'Vegan', 'Gluten-Free'],
    difficulty: 'Medium',
    prepTime: 20,
    cookTime: 30,
    servings: 2,
    image: 'https://images.pexels.com/photos/1095550/pexels-photo-1095550.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    shortDescription: 'A hearty and nutritious bowl with roasted seasonal vegetables and protein-rich quinoa.'
  },
  {
    id: 3,
    title: 'Lemon Herb Grilled Chicken',
    category: 'Main Dishes',
    tags: ['High-Protein', 'Gluten-Free'],
    difficulty: 'Easy',
    prepTime: 10,
    cookTime: 20,
    servings: 4,
    image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    shortDescription: 'Tender and juicy grilled chicken marinated in fresh lemon and herbs.'
  },
  {
    id: 4,
    title: 'Creamy Coconut Chia Pudding',
    category: 'Breakfast',
    tags: ['Vegetarian', 'Vegan', 'Gluten-Free'],
    difficulty: 'Easy',
    prepTime: 10,
    cookTime: 0,
    servings: 2,
    image: 'https://images.pexels.com/photos/16986726/pexels-photo-16986726/free-photo-of-chia-puddings-with-nut-butter-and-fresh-fruit.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    shortDescription: 'A delicious and nutritious breakfast option that can be prepared ahead of time.'
  },
  {
    id: 5,
    title: 'Rustic Apple Galette',
    category: 'Desserts',
    tags: ['Vegetarian', 'Baking'],
    difficulty: 'Medium',
    prepTime: 30,
    cookTime: 45,
    servings: 8,
    image: 'https://images.pexels.com/photos/6163263/pexels-photo-6163263.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    shortDescription: 'A beautiful free-form tart filled with sweet and tart apple slices.'
  },
  {
    id: 6,
    title: 'Mediterranean Stuffed Bell Peppers',
    category: 'Main Dishes',
    tags: ['Vegetarian', 'Gluten-Free'],
    difficulty: 'Medium',
    prepTime: 25,
    cookTime: 35,
    servings: 4,
    image: 'https://images.pexels.com/photos/5737247/pexels-photo-5737247.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    shortDescription: 'Colorful bell peppers stuffed with quinoa, vegetables, and Mediterranean flavors.'
  }
];

export const recipeCategories = [
  'All',
  'Breakfast',
  'Salads',
  'Soups',
  'Main Dishes',
  'Sides',
  'Desserts',
  'Bowls',
  'Snacks'
];

export const recipeTags = [
  'Vegetarian',
  'Vegan',
  'Gluten-Free',
  'Quick & Easy',
  'High-Protein',
  'Low-Carb',
  'Dairy-Free',
  'Baking'
];